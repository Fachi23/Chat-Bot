var socket = new WebSocket('ws://localhost:8181/', 'chat');
var name = 'u1'
socket.onopen = function () { 
    name1 = "name" + Math.floor(Math.random() * Math.floor(700));
    socket.send('{"type": "join", "name":" '+name1+'"}');
}

$('#send').on('click', function (e) {
    e.preventDefault();
    //name = 'u1',
    msg = $('#input').val();
    socket.send('{"type": "msg", "msg": "' + msg + '"}');
    $('#input').val('');
});
           
socket.onmessage = function (msg) {
var data = JSON.parse(msg.data)
var documentheight = 5000
switch (data.type) {
  case 'msg':
    if(data.name == "Notruf Bot"){
      var msg1=  $.parseHTML("<div class=\"msg left-msg\" id = \"msgl\"><div class=\"msg-img\"></div><div class=\"msg-bubble\"><div class=\"msg-info\"><div class=\"msg-info-name\">"+data.name+"</div>" 
      + "<div class=\"msg-info-time\">"+currentTime()+"</div></div> <div class=\"msg-text\"> " + data.msg + "</div>  </div></div>")
    }
    else{
      var msg1=  $.parseHTML("<div class=\"msg right-msg\" id = \"msgr\"><div class=\"msg-img\"></div><div class=\"msg-bubble\"><div class=\"msg-info\"><div class=\"msg-info-name\">Du</div>" 
      + "<div class=\"msg-info-time\">"+currentTime()+"</div></div> <div class=\"msg-text\"> " + data.msg + "</div>  </div></div>")       
    }
    $('#chat').append(msg1)
    $('#chat').animate({scrollTop:documentheight}, "fast")
    break;
  case 'join':
    $('#users').empty();
    for (var i = 0; i < data.names.length; i++) {
      var user = $('<div>' + data.names[i] + '</div>')
      $('#users').append(user);
    }
    break;
}
}

function currentTime(){
    var today = new Date();
    var hour = "0"
    var minute = "0"
    if(today.getHours()<10){
      hour +=today.getHours().toString()
    } else{
      hour = today.getHours().toString()
    }
    var minute = "0"
    if(today.getMinutes()<10){
      minute += today.getMinutes().toString()
    } else{
      minute = today.getMinutes().toString()
    }
    var time = hour + ":" + minute
   return time.toString();
  }
;