function currentTime(){
    var today = new Date();
    var hour = "0"
    var minute = "0"
    if(today.getHours()<10){
      hour +=today.getHours().toString()
    } else{
      hour = today.getHours().toString()
    }
    var minute = "0"
    if(today.getMinutes()<10){
      minute += today.getMinutes().toString()
    } else{
      minute = today.getMinutes().toString()
    }
    var time = hour + ":" + minute
   return time.toString();
  }
  function getMessage(){
    var answerPossibilities = ["Lego City Notruf: Wie ist ihre Straße und Hausnummer?"]
    return answerPossibilities[0]
  }
  $('#chat').append("<div class=\"msg left-msg\" id = msgl><div class=\"msg-img\"></div><div class=\"msg-bubble\"><div class=\"msg-info\"><div class=\"msg-info-name\">" + "Notruf Bot" +"</div>" 
              + "<div class=\"msg-info-tibotme\">"+ currentTime() + "</div></div> <div class=\"msg-text\" id = 454 > " + getMessage() + "</div>  </div></div>");