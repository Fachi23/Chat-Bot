'use strict'

var WebSocketClient = require('websocket').client
var requestpromise = require('request-promise')
var querystring = require('querystring')
const { Stats, stat } = require('fs')

/**
 * bot ist ein einfacher Websocket Chat Client
 */

class bot {
  

  /**
   * Konstruktor baut den client auf. Er erstellt einen Websocket und verbindet sich zum Server
   * Bitte beachten Sie, dass die Server IP hardcodiert ist. Sie müssen sie umsetzten
   */

  
  constructor () {
  
    this.Vorname = ''
    this.Nachname = ''
    this.status = 'start'
    this.street = ''
    this.housenumber = ''
    this.policeNeeded = false
    this.liveinDanger = false
    this.numberOfPeople = 1
    this.event = ''
    this.telNumber = ''

    
      

    /** Die Websocketverbindung
      */
    this.client = new WebSocketClient()
    /**
     * Wenn der Websocket verbunden ist, dann setzten wir ihn auf true
     */
    this.connected = false

    /**
     * Wenn die Verbindung nicht zustande kommt, dann läuft der Aufruf hier hinein
     */
    this.client.on('connectFailed', function (error) {
      console.log('Connect Error: ' + error.toString())
    })

    /** 
     * Wenn der Client sich mit dem Server verbindet sind wir hier 
    */
    this.client.on('connect', function (connection) {
      this.con = connection
      console.log('WebSocket Client Connected')
      connection.on('error', function (error) {
        console.log('Connection Error: ' + error.toString())
      })

      /** 
       * Es kann immer sein, dass sich der Client disconnected 
       * (typischer Weise, wenn der Server nicht mehr da ist)
      */
      connection.on('close', function () {
        console.log('echo-protocol Connection Closed')
      })

      /** 
       *    Hier ist der Kern, wenn immmer eine Nachricht empfangen wird, kommt hier die 
       *    Nachricht an. 
      */
      connection.on('message', function (message) {
        if (message.type === 'utf8') {
          var data = JSON.parse(message.utf8Data)
          console.log('Received: ' + data.msg + ' ' + data.name)
        }
      })

      /** 
       * Hier senden wir unsere Kennung damit der Server uns erkennt.
       * Wir formatieren die Kennung als JSON
      */
      function joinGesp () {
        if (connection.connected) {
          connection.sendUTF('{"type": "join", "name":"Notruf Bot"}')
        }
      }
      joinGesp()
    })
  }

  /**
   * Methode um sich mit dem Server zu verbinden. Achtung wir nutzen localhost
   * 
   */
  connect () {
    this.client.connect('ws://localhost:8181/', 'chat')
    this.connected = true
  }

  processMassage (message){
    message = message.toString()
    this.getPrediction(message)
  }


  	
  getPrediction = async (utterance) => {
    // starter-key from LUIS
    var endpointKey = "72093b1072f84fddbaee4189167ac075"
    // access html from LUIS
    var endpoint = "internettechnologien.cognitiveservices.azure.com"
    //LUIS_APP_ID environment variable 
    var appId = "adbb0103-1083-48fe-966e-5ed51d7722a1"

    // creates the search-string
    var queryParams = {
      "show-all-intents": true,
      "verbose":  true,
      "query": utterance,
      "subscription-key": endpointKey
    }
    // creates the rest-CALL
    var URI = `https://${endpoint}/luis/prediction/v3.0/apps/${appId}/slots/production/predict?${querystring.stringify(queryParams)}`
  // creates the answer, using the LUIS-data
  const data = await requestpromise(URI)
  this.processData(data)
  }

  /**
     * Decide on how to process the incoming message depending on the current state of the conversation
     */
  processData(data){
    var intents = require	('./intents.json')
    var name = 'Officer Bot'
    var inhalt = 'Ich habe dich nicht verstanden wir wollten über Notfälle reden'
    
    data = JSON.parse(data)
    console.log(data)
    
    if(data.prediction.topIntent == "Utilities.StartOver"){
      inhalt = this.reset()
    }else{
      switch(this.status){
        case('start'):
          inhalt = this.calculateAdress(data)
          break
        case('housenumber'):
          inhalt = this.calculateHousenumber(data)
          break
        case('name'): 
          inhalt = this.calculateName(data)
          break
        case('Vorname'):
          inhalt = this.calculateMissingNamePart(data)
          break
        case('Nachname'):
          inhalt = this.calculateMissingNamePart(data)
          break
        case('telNum'):
          inhalt = this. calculateMissingTelNum(data)
          break   
        case('emergencyDetails'):
          inhalt = this.calculateHelpersNeeded(data)
          break
        case('NumberOfPeople'):
          inhalt = this.calculateNumberOfPeopleHurt(data)
          break
        case('LiveInDanger'):
          inhalt = this.calculateConsciousness(data)
          break
        case('askForBreathing'):
          inhalt = this.calculateBreathing(data)
          break
        case ('confirmation'):
          inhalt = this.evaluateConfirmation(data)
          break
        case ('idle'):
          inhalt = this.evaluateCorrection(data)
          break    
      }
    }
    var msg = '{"type": "msg", "name": "' + name + '", "msg":"' + inhalt + '"}'
    console.log('Send: ' + msg)
    this.client.con.sendUTF(msg)
  }

  calculateAdress(data){
    var streetExists = data.prediction.entities.street !== undefined
    var housenumberExists = data.prediction.entities.Number !== undefined
    if(streetExists && housenumberExists){
      this.street = data.prediction.entities.street
      this.housenumber = data.prediction.entities.Number
      console.log(this.street+this.housenumber)
      this.status = 'name'
      return('Ok, wie ist ihr voller Name und Ihre Telefonnummer?')
    } else if(streetExists){
      this.street = data.prediction.entities.street
      this.status = 'housenumber'
      return('Die Straße ist also '+ this.street + '. Gibt es auch noch eine Hausnummer?')
      
    }
    return('Das habe ich leider nicht ganz verstanden können Sie die Straße und Hausnummer noch einmal wiederholen?')
  }

  calculateHousenumber(data){
    if(data.prediction.entities.Number !== undefined){
      this.housenumber = data.prediction.entities.Number
    }
    this.status = 'name'
    return('Ok, wie ist ihr voller Name und Ihre Telefonnummer?')
  }

  calculateName(data){
    var VornameExists = data.prediction.entities.Vorname !== undefined
    var NachnameExists = data.prediction.entities.Nachname !== undefined
    var telNumExists = data.prediction.entities.telefonnummer !== undefined
    if(VornameExists && NachnameExists&& telNumExists){
      this.Nachname = data.prediction.entities.Nachname
      this.Vorname = data.prediction.entities.Vorname
      this.telNumber = data.prediction.entities.telefonnummer
      this.status = 'emergencyDetails'
      return('Was ist passiert?')
    }else if(VornameExists && NachnameExists){
      this.Nachname = data.prediction.entities.Nachname
      this.Vorname = data.prediction.entities.Vorname
      this.status = 'telNum'
      return('Können Sie mir bitte Ihre Telefonnummer nennen?')
    }else if(VornameExists && telNumExists){
      this.Vorname = data.prediction.entities.Vorname
      this.telNumber = data.prediction.entities.telefonnummer
      this.status = 'Nachname'
      return('Können Sie mir bitte Ihren Nachnamen nennen?')
    }else if(NachnameExists && telNumExists){
      this.Nachname = data.prediction.entities.Nachname
      this.telNumber = data.prediction.entities.telefonnummer
      this.status = 'Vorname'
      return('Können Sie mir bitte Ihren Vornamen nennen?')
    }else if(telNumExists){
      this.telNumber = data.prediction.entities.telefonnummer
      this.status = 'Vorname'
      return('Können Sie mir bitte Ihren Vornamen nennen?')
    }else if(VornameExists){
      this.Vorname = data.prediction.entities.Vorname
      this.status = 'Nachname'
      return('Können Sie mir bitte Ihren Nachnamen nennen?')
    }else if(NachnameExists){
      this.Nachname = data.prediction.entities.Nachname
      this.status = 'Vorname'
      return('Können Sie mir bitte Ihren Vornamen nennen?')
    }
    return('Können Sie Ihren Namen und Ihre Telefonnummer bitte noch einmal wiederholen?')
  }

  calculateMissingNamePart(data){
    var VornameExists = data.prediction.entities.Vorname !== undefined
    var NachnameExists = data.prediction.entities.Nachname !== undefined
    var telNumExists = data.prediction.entities.telefonnummer !== undefined
    if(this.Vorname === ''&&VornameExists){
      this.Vorname = data.prediction.entities.Vorname
      if(this.Nachname === ''){
        this.status = 'Nachname'
        return('Können Sie mir bitte Ihren Nachnamen nennen?')
      }else if(this.telNumber === ''){
        this.status = 'Nachname'
        return ('Können Sie mir bitte Ihre Telefonnummer nennen?')
      }else{
        this.status = 'emergencyDetails'
        return('Was ist passiert?')
      }
    }else if(this.Nachname === ''&& NachnameExists){
      this.Nachname = data.prediction.entities.Nachname
      if(this.Vorname === ''){
        this.status = 'Vorname'
        return('Können Sie mir bitte Ihren Vornamen nennen?')
      }else if(this.telNumber === ''){
        this.status = 'Nachname'
        return ('Können Sie mir bitte Ihre Telefonnummer nennen?')
      }else{
        this.status = 'emergencyDetails'
        return('Was ist passiert?')
      }
    }else if(this.telNumber === ''&& telNumExists){
      this.telNumber = data.prediction.entities.telefonnummer
      if(this.Nachname === ''){
        this.status = 'Nachname'
        return('Können Sie mir bitte Ihren Nachnamen nennen?')
      }else if(this.telNumber === ''){
        this.status = 'Nachname'
        return ('Können Sie mir bitte Ihre Telefonnummer nennen?')
      }else{
        this.status = 'emergencyDetails'
        return('Was ist passiert?')
      }
    }
    return('Können Sie das noch einmal wiederholen?')
  }

  calculateMissingTelNum(data){
    if(data.prediction.entities.telefonnummer !== undefined){
      this.status = 'emergencyDetails'
      this.telNumber = data.prediction.entities.telefonnummer
      return('Was ist passiert?')
    }else{
      return('Können Sie Ihre Telefonnummer wiederholen?')
    }
  }

  calculateHelpersNeeded(data){
    this.policeNeeded = data.prediction.entities.Polizei !== undefined
    this.liveinDanger = data.prediction.entities.LiveInDanger !== undefined
    if(data.prediction.entities.Number !== undefined){
      this.Number = data.prediction.entities.Number
    }
    if(data.prediction.entities.Event !== undefined && this.numberOfPeople === 1){
      this.status = 'NumberOfPeople'
      this.event = data.prediction.entities.Event
      return('Wie viele Personen sind beteiligt?')
    }else if(data.prediction.entities.Event !== undefined){
      this.status = 'summary'
      this.numberOfPeople = data.prediction.entities.Number
      this.event = data.prediction.entities.Event
      return(this.constructSummary())
    }
    return('Können Sie die Situation noch einmal Beschreiben?')

  }

  calculateNumberOfPeopleHurt(data){
    this.numberOfPeople =this.lookForNumberInString(data.query)
    if(data.prediction.entities.Number !== undefined && !this.liveinDanger){
      this.status = 'summary'
      this.numberOfPeople = data.prediction.entities.Number
      return this.constructSummary()
    }else if(this.numberOfPeople !== 0 && !this.liveinDanger){
      this.status = 'summary'
      return this.constructSummary()
    }else if(data.prediction.entities.Number !== undefined){
      this.status = 'LiveInDanger'
      this.numberOfPeople = data.prediction.entities.Number
      return 'Sind alle Personen bei Bewusstsein?'
    }else if(this.numberOfPeople !== 0 && !this.liveinDanger){
      this.status = 'LiveInDanger'
      return 'Sind alle Personen bei Bewusstsein?'
    }
    return('Können Sie noch einmal wiederholen wie viele Leute verletzt sind?')
  }

  calculateConsciousness(data){
    if(data.prediction.intents.confirm.score>data.prediction.intents.deny.score){
      this.status = 'summary'
      return 'Gut. ' + this.constructSummary()
    }
    this.status = 'askForBreathing'
    return 'Atmen alle bewusstlosen Personen?'
  }

  calculateBreathing(data){
    if(data.prediction.intents.confirm.score>data.prediction.intents.deny.score){
      this.status = 'summary'
      return 'Bringen Sie alle bewusstlosen Personen in die stabile Seitenlage. ' + this.constructSummary()
    }
    this.status = 'summary'
    return 'Starten Sie sofort Herz-Lungen-Wiederbelebung. ' + this.constructSummary()
  }

  constructSummary(){
    var answer = 'Ich schicke '
    if(this.numberOfPeople < 4){
      answer = answer + this.numberOfPeople + ' Krankenwagen zur Adresse '
    }
    else{
      answer = answer + 'alle verfügbaren Krankenwagen zur Adresse '
    }
    answer = answer + this.street
    if(this.housenumber!==''){
      answer = answer + ' ' + this.housenumber
    }
    answer = answer + '.'
    if(this.policeNeeded){
       answer = answer + ' Außerdem alarmiere ich die Polizei.'
    }
    answer = answer + ' Ihr Name ist ' + this.Nachname + ', ' + this.Vorname + ' und Ihre Telefonnummer ist '+ this.telNumber +'. Stimmen diese Angaben?'
    this.status = 'confirmation'
    return answer
  }

  evaluateConfirmation(data){
    if(data.prediction.intents.confirm.score>data.prediction.intents.deny.score){
      this.status = 'idle'
      return('Gut. Bei neuen Information schreiben Sie bitte noch einmal')
    }else{
      this.status = 'idle'
      return('Ok, schreiben Sie bitte die korrigierten Daten')
    }
  }
  
  evaluateCorrection(data){
    switch(data.prediction.topIntent){
      case 'Adress':
        if(data.prediction.entities.street === undefined){
          return('Die Straße habe ich nicht ganz verstanden können Sie das noch einmal wiederholen')
        }
        this.calculateAdress(data)
        break
      case 'Name':
        if(data.prediction.entities.telefonnummer !== undefined){
          this.telNumber = data.prediction.entities.telefonnummer
        }
        this.calculateName(data)
        break
      case 'EventDescription':
        if(data.prediction.entities.Event === undefined){
          return('Wie ist die Situation genau?')
        }
        this.calculateHelpersNeeded(data)
        break  
      default:
        return('Das habe ich nicht ganz verstanden, können Sie die Informationen noch einmal wiederholen?')  
    }
    this.status = 'idle'
    return this.constructSummary()
  }

  reset(){
    this.Vorname = ''
    this.Nachname = ''
    this.status = 'start'
    this.street = ''
    this.housenumber = ''
    this.policeNeeded = false
    this.liveinDanger = false
    this.numberOfPeople = 1
    this.event = ''
    this.telNumber = ''
    return('Die Konversation wurde neu gestartet. Lego City Notruf: Wie ist ihre Straße und Hausnummer?')
  }

  lookForNumberInString(lookfor){
    var stringToSearch = "" + lookfor.toLowerCase()
    var numberInString = 0
    var NumberAsString = ['eine', 'zwei','drei','vier', 'fünf', 'sechs', 'sieben','elf','zwölf','dreizehn','vierzehn','fünfzehn','sechzehn','siebzehn','achtzehn','neunzehn','zwanzig']
    if(stringToSearch.includes('ich')){
      numberInString = 1
    }
    for (var number = 0; number < 21; number++) {
        if (stringToSearch.includes(NumberAsString[number])) {
            return (number+1).toString()
        }
    }
    return numberInString
}

}

module.exports = bot
